

/* Assignment 2:
Design a system for the following scenario:
1. An item list contains item code, name, rate, and quantity for several items.
2. Whenever a new item is added in the list uniqueness of item code is to be checked. Register a new product
with its price.
3. Time to time rate of the items may change.
4. Whenever an item is issued or received existence of the item is checked and quantity is updated.
5. In case of issue, availability of quantity is also to be checked.
6. User may also like to know price/quantity available for an item.
7. Find how many items cost more than a given amount. The amount will be a parameter. 8. Remember
that the methods have to return an error code if for example an invalid item code is given 
NOTE:
    � The system should be maintained by two types of user, one is Stock entry operator(SEO) and other is
    Shopkeeper (SK) and SEO will be the first operator in default case.
    � The SEO primarily maintain first 3 operations but SEO users can also maintain all operations (1 to 8)
    � SK users can only operates on 4 to 8.
    � System should be used for a specific shop type. Ex. Electronics, Book, Grocer etc.. You can design your
    system for any one.
    � Item Code should be auto generated that includes item name and entry order(1,2,3...)
Example: for Electronics shop
    Item name entry order Item Code
    Laptop 3 LAP003
    Mobile 2 MOB002
    Monitor 10 MON010
    Mouse 1 MOU001 
*/
package java_assignment_2;


import java.util.*;

class Shop
{

    String itemName, itemCode;
    int rate, quantity;
    static int entryOrder=0;
    int itemIssu = 0;
    
    Scanner scanner = new Scanner(System.in);
     
        // New Item entry by SEO
    void getItem()
    {
        System.out.print("\nEnter the Item name:  ");
        itemName = scanner.nextLine();
        entryOrder++;
        System.out.print("Enter the Item rate:  ");
        rate = scanner.nextInt();
        System.out.print("Enter the quantity of this Item:  ");
        quantity = scanner.nextInt();
        itemCode = setItemCode(entryOrder);

    }

        // SEO and SK can Issu any Item
    void itemIssu()
    {
        System.out.println("Press 1 for entry the Item Issu:\n Press 2 for show the Issued Item list");
        int issu = scanner.nextInt();
        String issuName;
        if(issu==1)
        {
            System.out.print("Enter the Issued Item name:  ");
            issuName = scanner.nextLine();
            if(quantity!=0)
                itemIssu++;
        }
        if(issu==2)
        {
            System.out.println("List of all the Issued product");
            if(itemIssu==1)
                System.out.println("Item name \tItem Code\t Quantity \n"+itemName+" \t"+itemCode+" \t"+quantity);
            else
                System.out.println("Issued Item is not avalable.....!!!");
        }
    }

        // Auto generated ItemCode
    String setItemCode(int entryOrder) 
    {
        String entry = Integer.toString(entryOrder);
        int code;
        String itemNo;
        
        if(entry.length()==1)
        {
            entry = "00"+entry;
            String itmNm=itemName.toUpperCase();
            itemNo = ((itmNm.substring(0,3)).concat(entry));
            return itemNo;
        }
        if(entry.length()==2)
        {
            entry = "0"+ entry;
            String itmNm=itemName.toUpperCase();
            itemNo = ((itmNm.substring(0,3)).concat(entry));
            return itemNo;
        }
        if(entry.length()==3)
        {
            String itmNm=itemName.toUpperCase();
            itemNo = ((itmNm.substring(0,3)).concat(entry));
            return itemNo;
        }
        return "Wrong Code";
        } 
            // Print the Item Data
    public String toString() 
    {
        return ("\n\nItem Name:\t"+itemName+"\nItem Code:\t"+itemCode+"\nPrice: \t\t"+rate+"\nQuantity:\t"+quantity);
    }
}

        /*      --:Main Class:--    */
class MyMain
{
     public static void main(String[] args) 
    {
        ArrayList<Shop> itemList = new ArrayList<Shop>();
        Shop sp[] = new Shop[100];
        int choice=0, itemNumber, person;
               
        Scanner myScanner = new Scanner(System.in);
        
            // For manue Selection
        do
        {
            System.out.println("\n\nPress 1:  Stock entry operator(SEO) \nPress 2: Shopkeeper (SK)");
            person = myScanner.nextInt();
            
            if(person == 1)
            {
                System.out.println("\n\n ----------------------: Stock entry operator(SEO) :------------------------------");
                System.out.println("Press 1 for Entry new item \nPress 2 for Show Item \nPress 3 for Order an Item \nPress 4 for Item Issu: \nPress 5 for know the quantity of Product: \nPress 6 for show the  how many items cost more than a given amount: \nPress 7 for Exit");
                choice = myScanner.nextInt();
            }

            if(person == 2)
            {
                System.out.println("\n\n ----------------------: Shopkeeper (SK) :------------------------------");
                System.out.println("Press 2 for Show Item \nPress 3 for Order an Item \nPress 4 for Item Issu: \nPress 5 for know the quantity of Product: \nPress 6 for show the  how many items cost more than a given amount: \nPress 7 for Exit");
                choice = myScanner.nextInt();   
            }
            
            switch(choice)
            {
                case 1:         // Entry new item
                    System.out.print("How many Item you want to entry in a Shop list:\t");
                    itemNumber = myScanner.nextInt();
                    for(int i=0;i<itemNumber;i++)
                    {
                        sp[i] = new Shop();
                        sp[i].getItem();                                                    
                        itemList.add(sp[i]); 
                    }
                break;
                
                case 2:     // Show Item
                    System.out.println("Item List is given below------------\n"+itemList);
                break;

                case 3:     // Order an Item
                    String itemOrder; 
                        System.out.println("Enter the Item name of your Order: ");
                        itemOrder = myScanner.next();
                    for(int i=0;i<itemList.size();i++)
                    {                           
                        String getName =itemList.get(i).itemName;
                        if(getName.equalsIgnoreCase(itemOrder))
                        {
                            (itemList.get(i).quantity)--; 
                            System.out.println("Item name: "+getName+" Ordered placed successfully...");
                            System.out.println("Current quantity of item "+ getName+" is "+itemList.get(i).quantity);   
                         }
                    } 
                break;

                case 4:         // Item Issu
                    System.out.println(" Press 1 for entry the Item Issu:\n Press 2 for show the Issued Item list");
                    int issu = myScanner.nextInt();
                    String issuName;
                    if(issu==1)
                    {   
                        System.out.println("Enter the Issued Item Name:\t ");
                        issuName = myScanner.next();
                        for(int i=0;i<itemList.size();i++)
                        {                           
                            String getName =itemList.get(i).itemName;
                            if(getName.equalsIgnoreCase(issuName))
                            {
                                (itemList.get(i).itemIssu)++;
                                System.out.println(getName+" Item issued successfully...");
                            }      
                        }
                    }
                    if(issu==2)
                    {
                        for(int i=0;i<itemList.size();i++)
                        {
                            if((itemList.get(i).itemIssu)==1)
                            {
                                System.out.println("Issued product");
                                System.out.println("Item name \tItem Code\t Quantity \n"+itemList.get(i).itemName+" \t"+itemList.get(i).itemCode+" \t\t"+itemList.get(i).quantity);
                            }  
                            else
                                System.out.println(itemList.get(i).itemName+" Item has no issu.");
                        }  
                    }
                break;

                case 5:     // Item quantity 
                    System.out.print("Enter the Item name which quantity you want to know: \t");
                    String name = myScanner.next();
                    for(int i=0;i<itemList.size();i++)
                    {
                        String getName = itemList.get(i).itemName;
                        if(getName.equalsIgnoreCase(name))
                            System.out.print("Quantity of "+name+" is: "+itemList.get(i).quantity);
                    }

                break;

                case 6:     // Item list > Enter price
                    System.out.print("Enter the Price:\t");
                    int myPrice = myScanner.nextInt();
                    System.out.println("List of tems which cost more than a given amount..... ");
                    for(int i=0;i<itemList.size();i++)
                    {
                        int getprice = itemList.get(i).rate;
                        if(getprice>myPrice)
                            System.out.println("\nItem name:\t"+itemList.get(i).itemName+"\nItem Price:\t"+itemList.get(i).rate);
                    }

                break; 
            }
        }while(choice!=7);
    }
}

