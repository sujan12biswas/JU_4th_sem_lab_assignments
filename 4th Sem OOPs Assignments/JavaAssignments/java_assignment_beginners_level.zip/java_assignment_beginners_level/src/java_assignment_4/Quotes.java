package java_assignment_4;



import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.*;
import java.time.*;

public class Quotes {
    private final String AM_QUOTES[] = {
        "Any fool can write code that a computer can understand. Good programmers write code that humans can understand. – Martin Fowler",
        "First, solve the problem. Then, write the code. – John Johnson",
        "Experience is the name everyone gives to their mistakes. – Oscar Wilde",
        " In order to be irreplaceable, one must always be different – Coco Chanel",
        "Java is to JavaScript what car is to Carpet. – Chris Heilmann",
        "Knowledge is power. – Francis Bacon",
        "Sometimes it pays to stay in bed on Monday, rather than spending the rest of the week debugging Monday’s code. – Dan Salomon"
    };
    
    private final String PM_QUOTES[] = {
        "Perfection is achieved not when there is nothing more to add, but rather when there is nothing more to take away. – Antoine de Saint-Exupery",
        "Ruby is rubbish! PHP is phpantastic! – Nikita Popov",
        " Code is like humor. When you have to explain it, it’s bad. – Cory House",
        "Fix the cause, not the symptom. – Steve Maguire",
        "Optimism is an occupational hazard of programming: feedback is the treatment. – Kent Beck",
        "When to use iterative development? You should use iterative development only on projects that you want to succeed. – Martin Fowler",
        "Simplicity is the soul of efficiency. – Austin Freeman",
        "Before software can be reusable it first has to be usable. – Ralph Johnson",
        "A big shot is a a little shot who keeps on shooting,so keep trying - Dr. A P J Abdul Kalam ",
        "Make it work, make it right, make it fast. – Kent Beck"                          
    }; 

    public String getQuote() throws IOException {
        String dayAndMonth = getDayAndMonth();
        String specialQuote;
        specialQuote = specialDates(dayAndMonth);
        if(specialQuote == null){
            String[] quotes;
            if (!isPM()) {
                quotes = AM_QUOTES;
            } else {
                quotes = PM_QUOTES;
            }

            String quote;
            int min = 0;
            int max = quotes.length;
            
            Random random = new Random(); 
            int x = random.nextInt(max - min) + min;
            quote = quotes[x];
            return new String(quote);
        }
        else
            return new String(specialQuote);
    }

    private boolean isPM() {
        String currentTimeStamp = getCurrentTimeStamp();
        return currentTimeStamp.substring(currentTimeStamp.length() - 2)
            .equals("PM");
    }

    private String getCurrentTimeStamp() {
        return new SimpleDateFormat("h:mm a").format(new Date());
    }

    private String getDayAndMonth(){
        LocalDate currentDate = LocalDate.now();
        int day = currentDate.getDayOfMonth();
        int month = currentDate.getMonthValue();
        String dayAndMonth = String.format("%02d/%02d", day, month);
        return dayAndMonth;
    }

    private String specialDates(String dayAndMonth){
        HashMap<String, String> specialDates = new HashMap<String, String>(){{
            put("01/01", "Happy New Year");
            put("23/01", "Netaji Jayanti");
            put("26/01", "Republic Day");
            put("15/08", "Independence Day");
            put("05/03", "Happy Birthday Nisha ");
        }};  
        return specialDates.get(dayAndMonth);
    }
}