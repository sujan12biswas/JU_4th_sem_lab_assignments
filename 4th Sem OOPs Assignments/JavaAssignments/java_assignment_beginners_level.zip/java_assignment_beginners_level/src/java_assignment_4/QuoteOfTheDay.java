package java_assignment_4;

import java.io.IOException;
import java.util.List;

public class QuoteOfTheDay {
    public static void main(String[] args) throws IOException {
        Quotes quote = new Quotes();
        System.out.println("THE QUETO OF THE DAY THAT MAKES YOU HAPPY IS ..... ");
        System.out.println(quote.getQuote());
    }
}