package java_assignment_1;

import java.util.*;

class myStudent
{
    int totalNumber = 0;
    String name;
    String addDate;
    int marks[] = new int[6];

        // Get Student data(Name, Date of Admission,marks)
    void getStdData()
    {
        Scanner getData = new Scanner(System.in);

        System.out.print("Enter the Student name:  ");
        name = getData.nextLine();
        System.out.print("Enter the Admission Date(DD/MM/YYYY):  ");
        addDate = getData.nextLine();
        System.out.println("Enter the marks of the student:--  ");
            // Getting marks of student
        for(int i=1; i<=5; i++)
        {
            System.out.print("Enter the subject "+i+" marks:  ");
            marks[i] = getData.nextInt();
            totalNumber = totalNumber + marks[i];
        }
    }
}

 class DeptStudent extends myStudent
{
    String dept;
    int choice;
    String Roll;
    static int deptId1 =0, deptId2=0, deptId3=0, deptId4=0; // Use to count student of each department
    Scanner scanner1 = new Scanner(System.in);
    
    @Override
    void getStdData()
    {
        super.getStdData();      // To overcome the situation method overriding for the derive class to the base class
        System.out.print("Press 1:BCSE 2:ETCE  3:MECHE  4:ITCE\t");
        choice = scanner1.nextInt();
        
        // Initialize Department Id for each student
        switch(choice)
        {
            case 1:
                dept = "BCSE";
                deptId1++;
            break;

            case 2:
                dept = "ETCE";
                deptId2++;
            break;

            case 3:
                dept = "MECHE";
                deptId3++;
            break;

            case 4:
                dept = "ITCE";
                deptId4++;
            break;

            default :
                System.out.println("Wrong Input.....!!!!");
            break;
        }

        // Getting Roll Number
        if(dept=="BCSE" && deptId1<=100)
        {
            Roll = getRoll(deptId1);
        }
        if(dept=="ETCE" && deptId2<=100)
        {
            Roll = getRoll(deptId2);
        }
        if(dept=="MECHE" && deptId3<=100)
        {
            Roll = getRoll(deptId3);
        }
        if(dept=="ITCE" && deptId4<=100)
        {
            Roll = getRoll(deptId4);
        }   
    }

        // Roll Number generating method:----
    String getRoll(int deptId)
        {
            String Id = Integer.toString(deptId);
            String roll;
            if(Id.length()==1)
            {
                Id = "00"+Id;
                roll = (dept.concat(addDate.substring(8))).concat(Id);
                return roll;
            }
            if(Id.length()==2)
            {
                Id = "0"+Id;
                roll = (dept.concat(addDate.substring(8))).concat(Id);
                return roll;
            }
            if(Id.length()==3)
            {
                roll = (dept.concat(addDate.substring(8))).concat(Id);
                return roll;
            }
            else
                System.out.println("Maximum 100 students can enter in each department...!!!");
        return "100";
        }
            //Print the Student details using the Array List
    public String toString()
    {            
        return ("\n\nName: "+name+"\nAdmission Date: "+addDate+"\nRoll No: "+Roll+"\nDepartment: "+dept+"\nSubject1 Marks:\t"+marks[1]+"\nSubject2 Marks:\t"+marks[2]+"\nSubject3 Marks:\t"+marks[3]+"\nSubject4 Marks:\t"+marks[4]+"\nSubject5 Marks:\t"+marks[5]+"\nTotal Number: "+totalNumber);

    }
}

     /*    --:For Collection Short:--      */
class SortbyName implements Comparator<DeptStudent>
{
    @ Override
    public int compare(DeptStudent st1, DeptStudent st2) 
    {    
        return st1.dept.compareTo(st2.dept);   
    }
}

    /*      --:Main Class:--      */
class StudentArray{
    public static void main(String []str)
    {
        ArrayList<DeptStudent> studentList = new ArrayList<DeptStudent>();      // ArrayList of DeptStudent object
        DeptStudent[] std = new DeptStudent[100];                               // Object array of DeptStudent Class
        Scanner scanner = new Scanner(System.in);
        int minNumber;
        Runtime memory = Runtime.getRuntime();                                  // For Memory
    
        System.out.print("How many student you want to enter in the system:\t");
        int stdNo = scanner.nextInt();
        for(int i=0;i<stdNo;i++)
        {
            std[i] = new DeptStudent();                                         // Memory allocation of DeptStudent Object
            std[i].getStdData();
            studentList.add(std[i]);                                            // Add Student object in the Array List
        }
        System.out.println("Unshorted Student Details Information:------------");
        System.out.println(studentList);

        Collections.sort(studentList, new SortbyName());                        // Short the Array List using Collections class & Implmenting Comparator Interface
        System.out.println("Shorted Student Details Information:------------");
        System.out.println(studentList);

        System.out.print("........................\nEnter minimum Total Number of Student which you want to show:  ");
        minNumber = scanner.nextInt();
        for(int i=0;i<studentList.size();i++)
        {
            if(studentList.get(i).totalNumber<=minNumber)
                studentList.remove(i);                                          // Remove the DeptStudent object from the ArrayList
        }
        System.out.println("-----------------Student List-------------");
        System.out.println(studentList);
            // Memory
        System.out.println("\n\nTotal Memory is:\t"+memory.totalMemory());
        System.out.println("Free Memory :\t"+memory.freeMemory());
        memory.gc();                                                            // Calling the Garbage Collector
        System.out.println("Free Memory after Garbage Collection:\t"+memory.freeMemory());
    }
}
