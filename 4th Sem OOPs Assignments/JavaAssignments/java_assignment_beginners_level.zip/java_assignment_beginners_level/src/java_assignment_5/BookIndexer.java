package java_assignment_5;



import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;  
import java.io.*;

public class BookIndexer {

  public static void main(String[] args) throws IOException {
    Reader br = getReader(args);
    Map<String, List<Integer>> indexMap = getOccurencesMap(br);
    indexMap.entrySet().forEach(index -> {
      System.out.println(index.getKey() + " " + index.getValue());
    });
  }

  private static Reader getReader(String[] args) {
    if (args.length == 0) {
      return new BufferedReader(new InputStreamReader(System.in));
    } else {
      try {
        return new BufferedReader(new FileReader(args[0]));
      } catch (FileNotFoundException e) {
        throw new IllegalArgumentException("The given file does not exist.", e);
      }
    }
  }

  private static Map<String, List<Integer>> getOccurencesMap(Reader text) throws IOException {
    try (LineNumberReader reader = new LineNumberReader(text)) {
      return reader.lines()
        .flatMap(Pattern.compile("\\s+")::splitAsStream)
        .map(w -> w.toLowerCase())
        .collect(Collectors.groupingBy(
          w -> w,
          Collectors.mapping(w -> reader.getLineNumber(), Collectors.toList())
        ));
    }
  }

}