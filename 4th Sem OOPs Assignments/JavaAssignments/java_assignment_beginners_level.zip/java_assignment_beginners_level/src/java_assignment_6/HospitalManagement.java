package java_assignment_6;



import java.io.*;
import java.util.*;

class HospitalManagement  {
    public static void main (String args []) {
        Scanner sc = new Scanner(System.in);
        Hospital h = new Hospital ();
        while(true) {
            int ch = 0;
            System.out.print ("1. Register Patient\n2. Register Doctor\n3. Remove Patient\n4. Update Patient's Record\n5. Display Patient By Id\n6. Display All Patients\n7. Display Patient's Under a Doctor\n8. exit\nEnter Choice :- ");
            ch = sc.nextInt ();
            switch (ch) {
                case 1: h.addPatient();
                        break;
                case 2: h.addDoctor();
                        break;
                case 3: String pid = new String ();
                        System.out.print ("Enter the patient's Id :- ");
                        pid = sc.next();
                        h.removePatient(pid);
                        break;
                case 4: String pid1 = new String ();
                        System.out.print ("Enter the patient's Id :- ");
                        pid1 = sc.next();
                        h.updateRecord(pid1);
                        break;
                case 5: String pid2 = new String ();
                         System.out.print("Enter the patient's Id :- ");
                        pid2 = sc.next();
                        h.showPatientById(pid2);
                        break;
                case 6: h.showAllPatients();
                        break;
                case 7: String docId = new String();
                        System.out.print ("Enter the doctor's Id :- ");
                        docId = sc.next();
                        h.displayPatientsUnderDoctor(docId);
                        break;
                default: System.exit(0);
            }
        }
    }
}

