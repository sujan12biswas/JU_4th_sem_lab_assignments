package java_assignment_6;

import java.io.*;
import java.util.*;

public class Patient {
  private String pid;
  private String name;
  private int age;
  private int weight;
  private int bloodPressure;
  private int temperature;
  
  public void getData (String s1) {
    Scanner sc = new Scanner(System.in);
    System.out.print ("Enter Name of the patient :- ");
    name = sc.nextLine ();
    System.out.print ("Enter Age Of the patient :- ");
    age = sc.nextInt ();
    System.out.print ("Enter the weight of the patient (in kgs):- ");
    weight = sc.nextInt ();
    System.out.print ("Enter the measured Blood Pressure :- ");
    bloodPressure = sc.nextInt();
    System.out.print ("Enter the patient's body temperature :- ");
    temperature = sc.nextInt();

    pid = new String (s1);
    System.out.println ("Patient Id :- " + s1);
    System.out.println("--------------------------------");
  }

  public void showData () {
    System.out.println ("Patient Id :- " + pid);
    System.out.println ("Patient Name :- " + name);
    System.out.println ("Patient Weight :- " + weight);
    System.out.println ("Patient blood pressure :- " + bloodPressure);
    System.out.println ("Patient body temperature :- " + temperature);
  }
  
  public String returnId () {return pid;}

  public void updatePatient () {
    Scanner sc = new Scanner(System.in);
    System.out.print ("Enter the new weight of the patient (in kgs):- ");
    weight = sc.nextInt ();
    System.out.print ("Enter the newly measured Blood Pressure :- ");
    bloodPressure = sc.nextInt();
    System.out.print ("Enter the updated patient's body temperature :- ");
    temperature = sc.nextInt();
  }
}
