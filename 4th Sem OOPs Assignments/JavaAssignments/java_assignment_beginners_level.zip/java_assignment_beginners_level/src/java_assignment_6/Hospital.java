package java_assignment_6;


import java.io.*;
import java.util.*;

public class Hospital {
  PriorityQueue <Doctor> dlist = new PriorityQueue<Doctor> ();
  static private int pcount = 0;
  static private int pcount1 = 0;
  static private int dcount = 0;
  ArrayList<Patient> patientList = new ArrayList<Patient> ();

  void addPatient () { 
      Patient p = new Patient ();
      String pid = new String ("PAT21");
      String lastNumber = Integer.toString(pcount);
      if(lastNumber.length() == 1)
          pid += "00" + lastNumber;
      else if(lastNumber.length() == 2)
          pid += "0" + lastNumber;
      else
          pid += lastNumber;
      
      p.getData(pid);
      patientList.add(p);
      System.out.println ("Patient Registration Succesfull !");
      
      if(dlist.isEmpty ()){
          System.out.println ("No Doctors Found !... Please Try Again");
      }
      else {
          Doctor d = dlist.peek();
          System.out.println ("Doctor Assigned --------------------------- ");
          d.showData();
          dlist.remove();
          d.addPatient(p); 
          dlist.add(d); 
          System.out.println ("---------------------------------");
      }
      pcount++; 
      pcount1++; 
  }
  
  public void addDoctor () {
      Doctor d = new Doctor ();
      String docId = new String ("DOC21");
      String lastNumber = Integer.toString(dcount);
      if(lastNumber.length() == 1)
          docId += "00" + lastNumber;
      else if(lastNumber.length() == 2)
          docId += "0" + lastNumber;
      else
          docId += lastNumber;
      
      d.getData(docId);
      dlist.add(d);
      System.out.println ("Doctor Registered Successfully ! Doctor's Id :- " + docId);
      dcount++;
  }
  public int findPatientById (String pid) {
      int idx = -1;
      for (int i = 0; i < patientList.size(); i++) {
          if(patientList.get(i).returnId().equals(pid))
          {
              idx = i;
              break;
          }
      }
      return idx;
  }
  
  public void removePatient (String pid){
      int idx = findPatientById(pid);

      if(idx != -1){ 
          System.out.println("Patient Discharge Successful !");
          patientList.remove(idx);
          
          PriorityQueue<Doctor> dummy = new PriorityQueue<Doctor> ();
          while(!dlist.isEmpty()) {
              Doctor d = new Doctor();
              d = dlist.peek();
              dlist.remove();
              d.removePatient(pid);
              dummy.add(d);
          }
          dlist = dummy;
          pcount1--; 
      }
      else {
          System.out.println ("Patient to be discharged not found ! Try Again ...");
      }
  }
  
  public void updateRecord (String pid) {
      int idx = findPatientById(pid);
      if(idx != -1){
          Patient p = patientList.get(idx);
          p.updatePatient();

          PriorityQueue<Doctor> dummy = new PriorityQueue<Doctor> ();
          while(!dlist.isEmpty()) {
              Doctor d = new Doctor();
              d = dlist.peek();
              dlist.remove();
              int flag = d.findPatientById(pid);
              d.removePatient(pid);
              if(flag != - 1)
                  d.addPatientByRef(p);
              dummy.add(d);
          }
          dlist = dummy;
      }
      else {
          System.out.println ("Patient Record to be update not found ! Try Again...");
      }
  }

  public void showPatientById (String s) {
      int idx = findPatientById(s);
      if(idx != -1)
          patientList.get(idx).showData();
      else
          System.out.println ("Patient Details to be shown Not Found ! Please enter correct Id...");
  }
  
  public void showAllPatients () {
      System.out.println ("<-----------Currently registered Patients---------->");
      for(int i = 0; i < patientList.size(); i++) {
          patientList.get(i).showData();
          System.out.println ("-----------------------------");
      }
      System.out.println ("Currently Registered Patient Count :- " + pcount1);
  }
  
  public void displayPatientsUnderDoctor (String docId) {
      int k = 0;
      PriorityQueue<Doctor> dummy = new PriorityQueue<Doctor> ();
          while(!dlist.isEmpty()) {
              Doctor d = new Doctor();
              d = dlist.peek();
              if(d.returnId().equals(docId))
              {
                  d.showData();
                  System.out.println ("<------------Patient's List-------------->");
                  d.showPatient();
              }
              dlist.remove();
              dummy.add(d);
          }
          dlist = dummy;
  }
} 
