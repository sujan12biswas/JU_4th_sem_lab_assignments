package java_assignment_6;


import java.io.*;
import java.util.*;

public class Doctor implements Comparable <Doctor>{
 private String doctorId;
 private String doctorName;
 protected ArrayList<Patient> plist = new ArrayList<Patient> ();
 
 public void getData (String s) { 
     Scanner sc = new Scanner (System.in);
     System.out.print ("Enter the doctor's Name :- ");
     doctorName = sc.nextLine ();
     doctorId = new String (s);
 }
 
 public void showData () {
     System.out.println ("Doctor Name :- " + doctorName);
     System.out.println ("Doctor Id :- " + doctorId);
 }
 
 public int compareTo (Doctor d) { 
     return plist.size() - d.plist.size();
 } 
 
 public void addPatient(Patient p) {
     plist.add(p);
 }
 
 public int findPatientById (String pid) {
     int idx = -1;
     for (int i = 0; i < plist.size(); i++) {
         if(plist.get(i).returnId().equals(pid))
         {
             idx = i;
             break;
        }
     }
     return idx;
 }
 
 public void removePatient (String pid) {
     int idx = findPatientById(pid);
     if(idx != -1)
         plist.remove(idx);
 }
 
 public void updatePatientRecord (String pid) {
     int idx = findPatientById(pid);
     if(idx != -1) {
         Patient p = plist.get(idx);
         p.updatePatient();
     }
 } 
 
 public void showPatient () {
     int k = 0;
     for(int i = 0; i < plist.size(); i++) {
         plist.get(i).showData();
         System.out.println ("------------------------------"); 
         k++;
     }
     if(k == 0) {
         System.out.println ("No Patients to be displyed !");
     }
 }
  
 public  String returnId () {return doctorId;}
 
 public void addPatientByRef (Patient p) {plist.add(p);}
}