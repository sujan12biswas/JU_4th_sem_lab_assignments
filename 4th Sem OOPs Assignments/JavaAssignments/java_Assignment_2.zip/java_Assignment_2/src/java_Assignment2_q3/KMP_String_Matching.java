package java_Assignment2_q3;

import java.io.*;
import java.util.*;
import java.lang.*;

class KMP_String_Matching
{
    int KMPSearch(String pat, String txt)
    {
        int M = pat.length();
        int N = txt.length();
        int lps[] = new int[M];//lps is for longest prefix suffix
        int j = 0; // index for pattern
 
        // Preprocess the pattern (calculate lps[]
        // array)
        computeLPSArray(pat,M,lps);
 
        int i = 0; // index for txt
        int res = 0;
        int next_i = 0;
         
        while (i < N)
        {
            if (pat.charAt(j) == txt.charAt(i))
            {
                j++;
                i++;
            }
            if (j == M)
            {
                // When we find pattern first time,
                // we iterate again to check if there
                // exists more pattern
                j = lps[j-1];
                res++;
 
                // We start i to check for more than once
                // appearance of pattern, we will reset i
                // to previous start+1
                if (lps[j]!=0)
                    i = ++next_i;
                j = 0;
            }
 
            // mismatch after j matches
            else if (i < N && pat.charAt(j) != txt.charAt(i))
            {
                // Do not match lps[0..lps[j-1]] characters,
                // they will match anyway
                if (j != 0)
                    j = lps[j-1];
                else
                    i = i+1;
            }
        }
        return res;
    }
 
    void computeLPSArray(String pat, int M, int lps[])
    {
        // length of the previous longest prefix suffix
        int len = 0;
        int i = 1;
        lps[0] = 0; // lps[0] is always 0
 
        // the loop calculates lps[i] for i = 1 to M-1
        while (i < M)
        {
            if (pat.charAt(i) == pat.charAt(len))
            {
                len++;
                lps[i] = len;
                i++;
            }
            else // (pat[i] != pat[len])
            {
                // This is tricky. Consider the example.
                // AAACAAAA and i = 7. The idea is similar
                // to search step.
                if (len != 0)
                {
                    len = lps[len-1];
 
                    // Also, note that we do not increment
                    // i here
                }
                else // if (len == 0)
                {
                    lps[i] = len;
                    i++;
                }
            }
        }
    }
 

    
    public static void main(String[] args)
    {
        Scanner sc =new Scanner(System.in);
        System.out.println("enter the string: ");
        String txt = sc.nextLine();
        //String txt = "i am a girl and i am a student.";
        String pat = "a";
        int ans = new KMP_String_Matching().KMPSearch(pat,txt);
        System.out.println("The number of times a appear is :  ");
        System.out.println(ans);
        String pat1 = "and";
        int ans1 = new KMP_String_Matching().KMPSearch(pat1,txt);
        System.out.println("The number of times and appear is :  ");
        System.out.println(ans1);
        System.out.println("Now we are checking wheather the string is starts with the or not: ");
        //System.out.println(txt.startsWith("The"));
        if(txt.startsWith("The"))
        {
            System.out.println("YES the string starts with The ");
        }
        else{
            System.out.println("NO the string is not starting with The ");
        }
        System.out.println("Now we put the String into an array of characters:  ");
        int N = txt.length();
        char[] ch = new char[N];
        for(int i=0;i<N;i++)
        {
            ch[i]=txt.charAt(i);
        }
        for(char c:ch)
        {
            System.out.println(c);
        }
        System.out.println("Now we are display the tokens in the String: ");
        StringTokenizer st = new StringTokenizer(txt," ");
        while(st.hasMoreTokens())
        {
            System.out.println(st.nextToken());
        }
    }
}

