package java_Assignment2_q1;

import java.io.*;
import java.util.*;
import java.lang.*;


class BankAccount
{
  
    public static void main(String[] args)
    {
    double accNumber;
    double balance=0;
    double interest=.02;
    int yy;
    System.out.println("enter the acount number: ");
    Scanner sc =new Scanner(System.in);
    accNumber=sc.nextDouble();
    System.out.println("enter the balance: ");
    balance=sc.nextDouble();
    System.out.println("the amount with interest is : ");
    balance+=(balance*interest);
    //inter(balance,interest);
    System.out.println(balance);
    System.out.println("the default interest is 2% , dou u want to change the interest rate: ");
    System.out.println("press 1 to change and 0 to remain unchange the rate: ");
    yy=sc.nextInt();
    if(yy==1)
    {
        System.out.println("enter the new interest rate: ");
        interest=sc.nextDouble();
        //inter(balance,interest);
        System.out.println("the new interest rate and balance is: ");
        balance+=(balance*(.01*interest));
        System.out.println(interest);
        System.out.println(balance);

    }
    else{
        System.out.println("the amount with default interest is: ");
        System.out.println(balance);
    }


    }
}
