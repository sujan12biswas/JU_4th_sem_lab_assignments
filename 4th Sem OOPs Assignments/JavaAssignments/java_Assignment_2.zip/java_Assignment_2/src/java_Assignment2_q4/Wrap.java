package java_Assignment2_q4;


import java.util.*;
import java.io.*;

class Wrap
{
    public static void main(String[] args)
    {
    
        Scanner sc = new Scanner(System.in);
        System.out.println("enter the numeric value: ");
        int a = sc.nextInt();
        Integer intobj=new Integer(a);
        System.out.println("The value after conversion from basic type to object");
        System.out.print(intobj);
        int intvalue = intobj;
        System.out.println("\nThe value after conversion from object to basic datatype ");
        System.out.println(intvalue);
        System.out.println("\nThe value after conversion from numeric type to string ");
        String st=Integer.toString(a);
        System.out.println(st);
        //System.out.println("enter the string you want to convert to numeric object ");
        //System.out.println("\nThe value after conversion from string to numeric object ");
        //String c = "dd";
       //int val = Integer.parseInt(c);
        //System.out.println(val);
        //float f = Float.parseFloat(c);
        //System.out.println(f);


    }
} 