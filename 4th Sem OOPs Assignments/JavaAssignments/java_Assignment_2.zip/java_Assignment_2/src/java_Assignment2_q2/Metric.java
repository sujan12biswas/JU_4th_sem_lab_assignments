package java_Assignment2_q2;

import java.util.*;
import java.lang.*;
import java.io.*;
class Metric
{
    static double tomile(double kms)
    {
        double mile = kms / 1.5;
        return mile;
    }

    static double tokms(double mile)
    {
        double kms = mile * 1.5;
        return kms;
    } 
public static void main(String[] args)
{
    Scanner sc=new Scanner(System.in);
    System.out.println("enter the value of distance to convert kilometer into miles  : ");
    double kms=sc.nextDouble();
    System.out.println(kms+" kilometer is equal to :  "+tomile(kms)+" mile");
    System.out.println("enter the value of distance to convert miles into kilometer : ");
    double mile=sc.nextDouble();
    System.out.println(mile+" miles is equal to  :  "+tokms(mile)+" kilometer");
}
}